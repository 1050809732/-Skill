---
name: ppt-wps-draw
description: 在 Windows 上连接本机 PowerPoint 或 WPS 演示，将科研示意图、流程图和参考截图重建为可编辑形状，或按对象修改已有 PPT。适用于参考图复刻、原生矢量绘图和实时绘制。
---

# PPT / WPS 科研绘图

用 `scripts/office.ps1` 调用本机 COM 接口。无需 MCP 服务、API key 或宏设置。参考图理解由当前对话模型完成，脚本负责确定性绘制，不能独立识图。

## 调用

通过 Python 标准库启动器调用 Windows PowerShell 5.1 的 STA 进程，不修改系统执行策略。将 `<skill>` 替换为本文件所在目录，将 python 替换为环境中的 Python 可执行文件。路径用单引号。

```powershell
python '<skill>/scripts/office.py' probe --connect
python '<skill>/scripts/office.py' render --app powerpoint --scene 'D:/work/scene.json' --output 'D:/work/figure.pptx' --preview-dir 'D:/work/preview' --keep-open
python '<skill>/scripts/office.py' inspect --input-file 'D:/work/figure.pptx'
python '<skill>/scripts/office.py' patch --input-file 'D:/work/figure.pptx' --patch 'D:/work/changes.json' --output 'D:/work/figure-v2.pptx'
```

`--app` 为 auto、powerpoint 或 wps。auto 优先 PowerPoint，选定后连接失败会报错。probe --connect 会分别验证两种软件。命令返回 JSON；失败读取错误，不将部分结果视为完成。

## 参考图重建

1. 查看用户参考图并读取文字、画幅和连接关系。按背景、结构、连线、标注列元素清单，保留比例、颜色含义和箭头方向。不臆造科学内容或数据。
2. 阅读 [场景协议](references/scene-format.md)，创建 scene JSON。可用原图像素尺寸作为画布单位，脚本按输出页面尺寸缩放。对象使用稳定语义名称。
3. 文字用 text，常规几何用 shape，连接线用 line，不规则轮廓用 freeform。照片或显微图可单独作为 image，明确其仍是图片；不要把整页截图作为重建完成的结果。
4. render 到新文件，导出 PNG 并逐页查看，核对文字换行、元素覆盖、层级和连线，修正明显差异。需要整组复制时使用 group。
5. inspect 核对对象树和类型，说明哪些是原生图形、哪些是图片，不承诺任意截图自动无损矢量化。

## 已有文件修改

先 inspect 用户指定文件，用对象名称定位，组内对象采用 `组名/对象名` 路径。patch 支持更新文字、位置、大小、填充、线条、旋转，以及添加、复制、分组、解组和删除对象。

输入文件在内存中作为独立副本打开，输出必须另存到不同路径。覆盖既有输出需要 --overwrite。`--active` 仅供 inspect 当前窗口，编辑始终明确指定文件，不绕过脚本保护写回原件。

## 范围

- render 可新建，或基于 --input-file 复制模板后追加页面。
- inspect 读取文档对象树；export 输出 PNG 和可选 PDF。
- --keep-open 保留结果窗口，后续仍按明确文件路径操作。
- 示例在 assets/demo-scene.json。原生图表、公式编辑器、动画、独立 OCR 不在脚本范围。
- 遇到 COM 忙碌、对话框或 WPS 差异时修复具体错误，不修改宏设置、注册表或强杀用户进程。软件不可用则保留 scene，报告未通过的实际检查。
