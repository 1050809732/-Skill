"""Preserve native gradients and exact Bezier paths ignored by WPS COM methods."""
import argparse
import json
from pathlib import Path
import posixpath
import tempfile
import xml.etree.ElementTree as E
import zipfile

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
for key, value in NS.items():
    E.register_namespace(key, value)
E.register_namespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')


def a(tag):
    return '{' + NS['a'] + '}' + tag


def shape_nodes(root):
    """Yield (shape, semantic path, ancestor groups), including groups themselves."""
    def walk(parent, prefix='', groups=()):
        for child in parent:
            nv = child.find('.//p:cNvPr', NS)
            if nv is None:
                continue
            name = prefix + nv.get('name', '')
            yield child, name, groups
            if child.tag == '{' + NS['p'] + '}grpSp':
                yield from walk(child, name + '/', groups + (child,))
    yield from walk(root.find('p:cSld/p:spTree', NS))


def local_point(x, y, groups):
    x, y = x * 12700, y * 12700
    for group in groups:
        xf = group.find('p:grpSpPr/a:xfrm', NS)
        if xf is None:
            continue
        off, ext = xf.find('a:off', NS), xf.find('a:ext', NS)
        co, ce = xf.find('a:chOff', NS), xf.find('a:chExt', NS)
        if any(v is None for v in [off, ext, co, ce]):
            continue
        if int(xf.get('rot', '0')) or xf.get('flipH') == '1' or xf.get('flipV') == '1':
            raise ValueError('Exact path repair inside a rotated or flipped group is unsupported')
        x = (x - int(off.get('x'))) * int(ce.get('cx')) / max(1, int(ext.get('cx'))) + int(co.get('x'))
        y = (y - int(off.get('y'))) * int(ce.get('cy')) / max(1, int(ext.get('cy'))) + int(co.get('y'))
    return x, y


def gradient(sp, spec, transparency=0):
    prop = sp.find('p:spPr', NS)
    if prop is None:
        return
    for child in list(prop):
        if child.tag in {a(t) for t in ['solidFill', 'noFill', 'gradFill', 'pattFill', 'blipFill', 'grpFill']}:
            prop.remove(child)
    fill = E.Element(a('gradFill'), {'rotWithShape': '1'})
    stops = E.SubElement(fill, a('gsLst'))
    for pos, color in [(0, spec['from']), (100000, spec['to'])]:
        stop = E.SubElement(stops, a('gs'), {'pos': str(pos)})
        rgb = E.SubElement(stop, a('srgbClr'), {'val': color.lstrip('#').upper()})
        if transparency:
            E.SubElement(rgb, a('alpha'), {'val': str(round((1 - transparency) * 100000))})
    angles = {1: 0, 2: 90, 3: 45, 4: 135}
    if spec.get('style', 1) not in angles:
        raise ValueError('WPS native gradient repair supports styles 1..4')
    angle = angles[spec.get('style', 1)]
    if spec.get('variant', 1) in [2, 4]:
        angle += 180
    E.SubElement(fill, a('lin'), {'ang': str(angle * 60000), 'scaled': '1'})
    E.SubElement(fill, a('tileRect'))
    # Fill precedes line/effects in the DrawingML property sequence.
    position = next((i for i, c in enumerate(prop) if c.tag in {a('ln'), a('effectLst'), a('effectDag')}), len(prop))
    prop.insert(position, fill)


def freeform(sp, spec, groups, sx, sy):
    coords = []
    for point in spec['points']:
        coords.append([local_point(point[i] * sx, point[i + 1] * sy, groups)
                       for i in range(0, len(point), 2)])
    all_points = [pt for segment in coords for pt in segment]
    min_x, min_y = min(p[0] for p in all_points), min(p[1] for p in all_points)
    width = max(1, round(max(p[0] for p in all_points) - min_x))
    height = max(1, round(max(p[1] for p in all_points) - min_y))
    prop = sp.find('p:spPr', NS)
    xf = prop.find('a:xfrm', NS)
    if xf is None:
        xf = E.Element(a('xfrm'))
        prop.insert(0, xf)
    for tag, attrs in [('off', {'x': str(round(min_x)), 'y': str(round(min_y))}),
                       ('ext', {'cx': str(width), 'cy': str(height)})]:
        node = xf.find(a(tag))
        if node is None:
            node = E.SubElement(xf, a(tag))
        node.attrib.update(attrs)
    for child in list(prop):
        if child.tag in [a('custGeom'), a('prstGeom')]:
            prop.remove(child)
    geom = E.Element(a('custGeom'))
    for tag in ['avLst', 'gdLst', 'ahLst', 'cxnLst']:
        E.SubElement(geom, a(tag))
    E.SubElement(geom, a('rect'), {'l': 'l', 't': 't', 'r': 'r', 'b': 'b'})
    path = E.SubElement(E.SubElement(geom, a('pathLst')), a('path'), {'w': str(width), 'h': str(height)})
    for i, points in enumerate(coords):
        tag = 'moveTo' if i == 0 else ('cubicBezTo' if len(points) == 3 else 'lnTo')
        cmd = E.SubElement(path, a(tag))
        for x, y in points:
            E.SubElement(cmd, a('pt'), {'x': str(round(x - min_x)), 'y': str(round(y - min_y))})
    if spec.get('closed'):
        E.SubElement(path, a('close'))
    prop.insert(1, geom)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--file', required=True, type=Path)
    p.add_argument('--scene', type=Path)
    p.add_argument('--patch', type=Path)
    args = p.parse_args()
    source = json.loads((args.scene or args.patch).read_text(encoding='utf-8-sig'))
    with zipfile.ZipFile(args.file) as z:
        parts = {item.filename: (item, z.read(item.filename)) for item in z.infolist()}
    presentation = E.fromstring(parts['ppt/presentation.xml'][1])
    size = presentation.find('p:sldSz', NS)
    rels = E.fromstring(parts['ppt/_rels/presentation.xml.rels'][1])
    targets = {r.get('Id'): r.get('Target') for r in rels}
    slide_files = []
    for s in presentation.find('p:sldIdLst', NS):
        target = targets[s.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
        slide_files.append(target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('ppt', target)))
    if args.scene:
        sx = int(size.get('cx')) / 12700 / source['width']
        sy = int(size.get('cy')) / 12700 / source['height']
        # render appends supplied slides to any template.
        work = [(slide_files[len(slide_files) - len(source['slides']) + i], sl['elements'])
                for i, sl in enumerate(source['slides'])]
    else:
        sx = sy = 1
        by_slide = {}
        for op in source['operations']:
            if op['op'] == 'add':
                spec = dict(op['element'], _reset=True)
            elif op['op'] in ['update', 'duplicate']:
                spec = dict(op.get('set', {}), name=op.get('newName', op.get('name')))
            else:
                continue
            by_slide.setdefault(op.get('slide', 1), []).append(spec)
        work = [(slide_files[i - 1], specs) for i, specs in by_slide.items()]
    changes = 0
    for filename, specs in work:
        tree = E.fromstring(parts[filename][1])
        nodes = list(shape_nodes(tree))
        prepared = {}
        for spec in specs:
            if spec.get('kind') != 'freeform' and 'fill' not in spec:
                continue
            exact = [(sp, groups) for sp, path, groups in nodes if path == spec['name']]
            matches = exact or [(sp, groups) for sp, path, groups in nodes if path.split('/')[-1] == spec['name']]
            # A later delete may have removed an object added in the same patch.
            if not matches and args.patch:
                continue
            if len(matches) != 1:
                raise ValueError('Ambiguous or missing native object: ' + spec['name'])
            sp, groups = matches[0]
            key = id(sp)
            merged = {} if spec.get('_reset') else dict(prepared.get(key, (None, None, {}))[2])
            merged.update(spec)
            prepared[key] = (sp, groups, merged)
        for sp, groups, spec in prepared.values():
            needs_path = spec.get('kind') == 'freeform'
            needs_fill = isinstance(spec.get('fill'), dict)
            if needs_path:
                freeform(sp, spec, groups, sx, sy)
            if needs_fill:
                gradient(sp, spec['fill'], spec.get('transparency', 0))
            changes += int(needs_path or needs_fill)
        if changes:
            parts[filename] = (parts[filename][0], E.tostring(tree, encoding='utf-8', xml_declaration=True))
    if changes:
        with tempfile.NamedTemporaryFile(dir=args.file.parent, suffix='.pptx', delete=False) as f:
            temp = Path(f.name)
        try:
            with zipfile.ZipFile(temp, 'w') as z:
                for info, data in parts.values():
                    z.writestr(info, data)
            temp.replace(args.file)
        finally:
            temp.unlink(missing_ok=True)
    print(json.dumps({'ok': True, 'native_repairs': changes}))


if __name__ == '__main__':
    main()
