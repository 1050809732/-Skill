﻿[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('probe','render','inspect','patch','export')][string]$Action,
 [ValidateSet('auto','powerpoint','wps')][string]$App='auto',
 [string]$Scene,[string]$InputFile,[string]$Output,[string]$Patch,[string]$PreviewDir,[string]$Pdf,
 [switch]$Connect,[switch]$Active,[switch]$KeepOpen,[switch]$Overwrite
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$script:session=$null;$script:deck=$null;$script:owned=$false;$script:success=$false
$script:sx=1.0;$script:sy=1.0;$script:sf=1.0
$script:kinds=@{rect=1;roundRect=5;ellipse=9;triangle=7;diamond=4;hexagon=10;chevron=52;parallelogram=2;cloud=179;rightArrow=33;leftArrow=34;upArrow=35;downArrow=36;cylinder=13}
function Has($o,[string]$k){return ($null -ne $o -and $null -ne $o.PSObject.Properties[$k])}
function Val($o,[string]$k,$d){if(Has $o $k){return $o.$k};return $d}
function Full([string]$p){return [IO.Path]::GetFullPath($p)}
function ReadJson([string]$p){if(!$p -or !(Test-Path -LiteralPath $p -PathType Leaf)){throw "JSON file not found: $p"};return (Get-Content -LiteralPath $p -Raw -Encoding UTF8|ConvertFrom-Json)}
function RGB([string]$hex){
 if($hex -notmatch '^#?([0-9a-fA-F]{6})$'){throw "Invalid #RRGGBB color: $hex"};$h=$Matches[1]
 return [Convert]::ToInt32($h.Substring(0,2),16)+256*[Convert]::ToInt32($h.Substring(2,2),16)+65536*[Convert]::ToInt32($h.Substring(4,2),16)
}
function Destination([string]$p){
 if(!$p){throw 'Output path required'};$p=Full $p
 if($InputFile -and $p -ieq (Full $InputFile)){throw 'Input and output must differ'}
 if((Test-Path -LiteralPath $p) -and !$Overwrite){throw "Output exists; use -Overwrite explicitly: $p"};return $p
}
function Parent([string]$p){$dir=Split-Path -Parent $p;if(!(Test-Path -LiteralPath $dir)){[void](New-Item -ItemType Directory -Path $dir -Force)}}
function Session([string]$which,[bool]$running=$false){
 $existing=@(Get-Process -Name 'wpp','wps','POWERPNT' -ErrorAction SilentlyContinue).Count
 $id=if($which -eq 'wps'){'KWPP.Application'}else{'PowerPoint.Application'}
 if($which -eq 'auto' -and $null -eq [type]::GetTypeFromProgID($id)){$id='KWPP.Application'}
 if($null -eq [type]::GetTypeFromProgID($id)){throw "COM application not registered: $id"}
 $created=$false
 try{$obj=[Runtime.InteropServices.Marshal]::GetActiveObject($id)}catch{if($running){throw "No running application: $id"};$obj=New-Object -ComObject $id;$created=$true}
 $server=$null
 $reg='Registry::HKEY_CLASSES_ROOT\CLSID\{'+([type]::GetTypeFromProgID($id)).GUID.ToString()+'}\LocalServer32'
 if(Test-Path -LiteralPath $reg){$server=(Get-Item -LiteralPath $reg).GetValue('')}
 # WPS can return a singleton for New-Object; do not Quit any pre-existing Office process.
 return @{obj=$obj;created=($created -and $existing -eq 0);progid=$id;server=$server}
}
function OpenDeck{
 if(!$InputFile -or !(Test-Path -LiteralPath $InputFile -PathType Leaf)){throw 'InputFile must identify an existing presentation'}
 # Read-only, untitled copy: never edit the caller's open original.
 $script:deck=$script:session.obj.Presentations.Open((Full $InputFile),-1,-1,0);$script:owned=$true
}
function Lookup($slide,[string]$path){
 $parts=$path -split '/';$items=$slide.Shapes;$found=$null
 for($p=0;$p -lt $parts.Count;$p++){
  $found=$null
  for($i=1;$i -le $items.Count;$i++){if($items.Item($i).Name -ceq $parts[$p]){$found=$items.Item($i);break}}
  if($null -eq $found){throw "Object not found: $path"}
  if($p -lt $parts.Count-1){if($found.Type -ne 6){throw "Not a group: $($parts[$p])"};$items=$found.GroupItems}
 };return $found
}
function Style($shape,$s){
 if(Has $s 'fill'){
  if($null -eq $s.fill -or $s.fill -eq 'none'){$shape.Fill.Visible=0}else{
   $shape.Fill.Visible=-1
   if($s.fill -is [string]){$shape.Fill.Solid();$shape.Fill.ForeColor.RGB=RGB $s.fill}else{
    $shape.Fill.ForeColor.RGB=RGB $s.fill.from;$shape.Fill.BackColor.RGB=RGB $s.fill.to
    $shape.Fill.TwoColorGradient([int](Val $s.fill 'style' 1),[int](Val $s.fill 'variant' 1))
   }
  }
 }
 if(Has $s 'transparency'){$shape.Fill.Transparency=[single]$s.transparency}
 if(Has $s 'line'){if($null -eq $s.line -or $s.line -eq 'none'){$shape.Line.Visible=0}else{$shape.Line.Visible=-1;$shape.Line.ForeColor.RGB=RGB $s.line}}
 if(Has $s 'lineWidth'){$shape.Line.Weight=[single]($s.lineWidth*$script:sf)}
 if(Has $s 'dash'){$shape.Line.DashStyle=[int]$s.dash}
 if(Has $s 'arrowEnd'){$shape.Line.EndArrowheadStyle=[int]$s.arrowEnd}
 if(Has $s 'arrowStart'){$shape.Line.BeginArrowheadStyle=[int]$s.arrowStart}
 if(Has $s 'rotation'){$shape.Rotation=[single]$s.rotation}
 if(Has $s 'text'){$shape.TextFrame.TextRange.Text=[string]$s.text}
 if((Has $s 'text') -or (Has $s 'fontSize') -or (Has $s 'font') -or (Has $s 'textColor') -or (Has $s 'bold') -or (Has $s 'align')){
  $tr=$shape.TextFrame.TextRange
  if(Has $s 'font'){$tr.Font.Name=[string]$s.font;$tr.Font.NameFarEast=[string]$s.font}
  if(Has $s 'fontSize'){$tr.Font.Size=[single]($s.fontSize*$script:sf)}
  if(Has $s 'textColor'){$tr.Font.Color.RGB=RGB $s.textColor}
  if(Has $s 'bold'){$tr.Font.Bold=if($s.bold){-1}else{0}}
  if(Has $s 'align'){$a=@{left=1;center=2;right=3};if(!$a.ContainsKey([string]$s.align)){throw 'Invalid align'};$tr.ParagraphFormat.Alignment=$a[[string]$s.align]}
  if(Has $s 'valign'){$a=@{top=1;middle=3;bottom=4};if(!$a.ContainsKey([string]$s.valign)){throw 'Invalid valign'};$shape.TextFrame.VerticalAnchor=$a[[string]$s.valign]}
  if(Has $s 'margin'){$m=[single]($s.margin*$script:sf);$shape.TextFrame.MarginLeft=$m;$shape.TextFrame.MarginRight=$m;$shape.TextFrame.MarginTop=$m;$shape.TextFrame.MarginBottom=$m}
  $shape.TextFrame.WordWrap=-1
 }
 if(Has $s 'z'){if($s.z -eq 'front'){$shape.ZOrder(0)}elseif($s.z -eq 'back'){$shape.ZOrder(1)}else{throw 'z must be front or back'}}
}
function ValidateElement($s){
 if(!(Has $s 'name') -or !$s.name -or $s.name.Contains('/')){throw 'Elements need unique names without slash'}
 if($s.kind -notin @('shape','text','line','freeform','image','group')){throw "Unsupported kind: $($s.kind)"}
 if($s.kind -in @('shape','text','image')){foreach($k in @('w','h')){if(!(Has $s $k) -or [double]$s.$k -le 0){throw "$($s.name): $k must be positive"}}}
 foreach($k in @('line','textColor')){if((Has $s $k) -and $s.$k -and $s.$k -ne 'none'){[void](RGB $s.$k)}}
 if((Has $s 'fill') -and $s.fill -and $s.fill -ne 'none'){if($s.fill -is [string]){[void](RGB $s.fill)}else{[void](RGB $s.fill.from);[void](RGB $s.fill.to)}}
 if((Has $s 'transparency') -and ($s.transparency -lt 0 -or $s.transparency -gt 1)){throw 'transparency must be in [0,1]'}
}
function AddElement($slide,$s){
 ValidateElement $s
 for($i=1;$i -le $slide.Shapes.Count;$i++){if($slide.Shapes.Item($i).Name -ceq $s.name){throw "Duplicate name: $($s.name)"}}
 $x=[single]((Val $s 'x' 0)*$script:sx);$y=[single]((Val $s 'y' 0)*$script:sy)
 $w=[single]((Val $s 'w' 1)*$script:sx);$h=[single]((Val $s 'h' 1)*$script:sy);$obj=$null
 switch([string]$s.kind){
  'shape'{$type=Val $s 'shape' 'rect';if(!$script:kinds.ContainsKey([string]$type)){throw "Unknown shape: $type"};$obj=$slide.Shapes.AddShape($script:kinds[[string]$type],$x,$y,$w,$h)}
  'text'{$obj=$slide.Shapes.AddTextbox(1,$x,$y,$w,$h);$obj.Fill.Visible=0;$obj.Line.Visible=0;$obj.TextFrame.MarginLeft=0;$obj.TextFrame.MarginRight=0;$obj.TextFrame.MarginTop=0;$obj.TextFrame.MarginBottom=0}
  'line'{
   $obj=$slide.Shapes.AddConnector([int](Val $s 'connector' 1),$x,$y,[single]($s.x2*$script:sx),[single]($s.y2*$script:sy))
   if(Has $s 'begin'){$target=Lookup $slide $s.begin.name;$obj.ConnectorFormat.BeginConnect($target,[int](Val $s.begin 'site' 1))}
   if(Has $s 'end'){$target=Lookup $slide $s.end.name;$obj.ConnectorFormat.EndConnect($target,[int](Val $s.end 'site' 1))}
  }
  'freeform'{
   $pts=@($s.points);if($pts.Count -lt 2){throw 'freeform requires at least two points'}
   $b=$slide.Shapes.BuildFreeform(0,[single]($pts[0][0]*$script:sx),[single]($pts[0][1]*$script:sy))
   for($n=1;$n -lt $pts.Count;$n++){$p=@($pts[$n]);if($p.Count -eq 6){$b.AddNodes(1,0,[single]($p[0]*$script:sx),[single]($p[1]*$script:sy),[single]($p[2]*$script:sx),[single]($p[3]*$script:sy),[single]($p[4]*$script:sx),[single]($p[5]*$script:sy))}elseif($p.Count -eq 2){$b.AddNodes(0,0,[single]($p[0]*$script:sx),[single]($p[1]*$script:sy))}else{throw 'Path segments need 2 or 6 numbers'}}
   if(Val $s 'closed' $false){$b.AddNodes(0,0,[single]($pts[0][0]*$script:sx),[single]($pts[0][1]*$script:sy))}
   $obj=$b.ConvertToShape();$obj.Fill.Visible=0
  }
  'image'{$p=[string]$s.path;if(![IO.Path]::IsPathRooted($p)){if(!$Scene){throw 'Patch images must use absolute paths'};$p=Join-Path (Split-Path -Parent (Full $Scene)) $p};if(!(Test-Path -LiteralPath $p -PathType Leaf)){throw "Image not found: $p"};$obj=$slide.Shapes.AddPicture((Full $p),0,-1,$x,$y,$w,$h)}
  'group'{$names=[object[]]@($s.members);if($names.Count -lt 2){throw 'Group needs two or more objects'};foreach($name in $names){[void](Lookup $slide $name)};$obj=$slide.Shapes.Range($names).Group()}
 }
 $obj.Name=[string]$s.name;Style $obj $s;return $obj
}
function ObjectInfo($s,[string]$prefix=''){
 $path=$prefix+$s.Name;$r=[ordered]@{name=$s.Name;path=$path;id=$s.Id;type=$s.Type;x=[math]::Round($s.Left,3);y=[math]::Round($s.Top,3);w=[math]::Round($s.Width,3);h=[math]::Round($s.Height,3);rotation=$s.Rotation}
 if($s.HasTextFrame -eq -1 -and $s.TextFrame.HasText -eq -1){$r.text=$s.TextFrame.TextRange.Text}
 if($s.Type -eq 6){$children=@();for($j=1;$j -le $s.GroupItems.Count;$j++){$children+=ObjectInfo $s.GroupItems.Item($j) ($path+'/')};$r.children=$children};return $r
}
function DeckInfo{
 $slides=@();for($i=1;$i -le $script:deck.Slides.Count;$i++){$sl=$script:deck.Slides.Item($i);$objects=@();for($j=1;$j -le $sl.Shapes.Count;$j++){$objects+=ObjectInfo $sl.Shapes.Item($j)};$slides+=@{index=$i;name=$sl.Name;objects=$objects}}
 return @{width=$script:deck.PageSetup.SlideWidth;height=$script:deck.PageSetup.SlideHeight;slides=$slides}
}
function Previews{
 $files=@()
 if($PreviewDir){$dir=Full $PreviewDir;if(!(Test-Path -LiteralPath $dir)){[void](New-Item -ItemType Directory -Path $dir -Force)}
  for($i=1;$i -le $script:deck.Slides.Count;$i++){$p=Join-Path $dir ('slide-{0:D2}.png' -f $i);if((Test-Path -LiteralPath $p) -and !$Overwrite){throw "Preview exists: $p"};$height=[int](1600*$script:deck.PageSetup.SlideHeight/$script:deck.PageSetup.SlideWidth);$script:deck.Slides.Item($i).Export($p,'PNG',1600,$height);$files+=$p}
 }
 if($Pdf){$p=Destination $Pdf;Parent $p;$script:deck.SaveAs($p,32);$files+=$p};return ,$files
}
function MoveObject($s,$c){
 foreach($pair in @(@('x','Left'),@('y','Top'),@('w','Width'),@('h','Height'))){if(Has $c $pair[0]){if($pair[0] -in @('w','h') -and $c.($pair[0]) -le 0){throw 'Width and height must be positive'};$s.($pair[1])=[single]$c.($pair[0])}};Style $s $c
}
try{
 if($Action -eq 'probe'){
  $results=@();foreach($pair in @(@('powerpoint','PowerPoint.Application'),@('wps','KWPP.Application'))){
   if($App -ne 'auto' -and $App -ne $pair[0]){continue};$r=[ordered]@{app=$pair[0];progid=$pair[1];registered=($null -ne [type]::GetTypeFromProgID($pair[1]));connected=$false}
   if($Connect -and $r.registered){$s=$null;try{$s=Session $pair[0];$r.version=[string]$s.obj.Version;$r.server=$s.server;$r.connected=$true}catch{$r.error=$_.Exception.Message}finally{if($s){if($s.created){$s.obj.Quit()};[void][Runtime.InteropServices.Marshal]::ReleaseComObject($s.obj)}}};$results+=$r
  };@{ok=$true;applications=$results}|ConvertTo-Json -Depth 20;exit 0
 }
 if($Active -and $Action -ne 'inspect'){throw '-Active is only supported for inspect'}
 $out=$null;$data=$null
 if($Action -in @('render','patch')){
  $out=Destination $Output;if([IO.Path]::GetExtension($out) -ine '.pptx'){throw 'Output extension must be .pptx'}
  if($Action -eq 'render'){$data=ReadJson $Scene;if(!$data.slides -or $data.width -le 0 -or $data.height -le 0){throw 'Scene needs positive width/height and slides'};foreach($sl in $data.slides){$seen=@{};foreach($e in $sl.elements){ValidateElement $e;if($seen.ContainsKey($e.name)){throw "Duplicate name: $($e.name)"};$seen[$e.name]=$true}}}
  else{
   $data=ReadJson $Patch;if(!$data.operations){throw 'Patch needs operations'};$newPaths=@{}
   foreach($op in $data.operations){
    if($op.op -notin @('update','add','delete','duplicate','group','ungroup')){throw "Unsupported operation: $($op.op)"}
    $key=([string](Val $op 'slide' 1))+':'+([string]$op.name).Split('/')[-1]
    if($op.op -eq 'add'){ValidateElement $op.element;if($op.element.kind -eq 'freeform'){$newPaths[([string](Val $op 'slide' 1))+':'+$op.element.name]=$true}}
    if($op.op -eq 'update' -and $newPaths.ContainsKey($key)){
     foreach($k in @('x','y','w','h')){if(Has $op.set $k){throw 'Save newly added freeform before changing its geometry in a separate patch'}}
    }
   }
  }
 }
 $script:session=Session $App ([bool]$Active);$script:session.obj.Visible=-1
 if($Active){$script:deck=$script:session.obj.ActivePresentation;if(!$script:deck){throw 'No active presentation'}}elseif($InputFile){OpenDeck}elseif($Action -eq 'render'){$script:deck=$script:session.obj.Presentations.Add(0);$script:owned=$true}else{throw 'InputFile required'}
 if($Action -eq 'render'){
  if(!$InputFile){$script:deck.PageSetup.SlideWidth=[single](Val $data 'pageWidth' $data.width);$script:deck.PageSetup.SlideHeight=[single](Val $data 'pageHeight' $data.height)}
  $script:sx=$script:deck.PageSetup.SlideWidth/[double]$data.width;$script:sy=$script:deck.PageSetup.SlideHeight/[double]$data.height;$script:sf=[math]::Min($script:sx,$script:sy)
  foreach($sl in $data.slides){$slide=$script:deck.Slides.Add($script:deck.Slides.Count+1,12);if(Has $sl 'name'){$slide.Name=[string]$sl.name};$slide.FollowMasterBackground=0;$slide.Background.Fill.Solid();$slide.Background.Fill.ForeColor.RGB=RGB (Val $sl 'background' '#FFFFFF');foreach($e in $sl.elements){[void](AddElement $slide $e)}}
 }
 if($Action -eq 'patch'){
  foreach($op in $data.operations){$n=[int](Val $op 'slide' 1);if($n -lt 1 -or $n -gt $script:deck.Slides.Count){throw "Slide out of range: $n"};$slide=$script:deck.Slides.Item($n)
   switch($op.op){
    'add'{[void](AddElement $slide $op.element)}
    'update'{MoveObject (Lookup $slide $op.name) $op.set}
    'delete'{(Lookup $slide $op.name).Delete()}
    'duplicate'{
     if(!$op.newName -or $op.newName.Contains('/')){throw 'duplicate needs newName without slash'}
     if($op.name.Contains('/')){throw 'Duplicate a top-level object or group; ungroup first for a child'}
     for($j=1;$j -le $slide.Shapes.Count;$j++){if($slide.Shapes.Item($j).Name -ceq $op.newName){throw 'newName exists'}}
     $source=Lookup $slide $op.name;$before=$slide.Shapes.Count
     [void]$source.Duplicate()
     if($slide.Shapes.Count -eq $before){$source.Copy();[void]$slide.Shapes.Paste()}
     if($slide.Shapes.Count -ne $before+1){throw 'Application did not create exactly one duplicate'}
     $copy=$slide.Shapes.Item($slide.Shapes.Count);$copy.Name=[string]$op.newName
     if(Has $op 'set'){MoveObject $copy $op.set}
    }
    'group'{[void](AddElement $slide ([pscustomobject]@{kind='group';name=$op.name;members=$op.members}))}
    'ungroup'{[void](Lookup $slide $op.name).Ungroup()}
   }
  }
 }
 if($out){
  Parent $out;$script:deck.SaveAs($out,24)
  # WPS accepts some COM methods while silently discarding Bezier/gradient parameters.
  # Repair these as native DrawingML after closing our independent copy, then reopen.
  if($script:session.server -match '(?i)(wps|wpp)\.exe' -and $env:PPT_WPS_PYTHON){
   $script:deck.Close();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:deck);$script:deck=$null
   $repair=Join-Path (Split-Path -Parent $env:PPT_WPS_SCRIPT) 'native_xml.py'
   $args=@($repair,'--file',$out)
   if($Action -eq 'render'){$args+=@('--scene',(Full $Scene))}else{$args+=@('--patch',(Full $Patch))}
   $repairOutput=& $env:PPT_WPS_PYTHON @args
   if($LASTEXITCODE -ne 0){throw "Native compatibility repair failed: $repairOutput"}
   $script:deck=$script:session.obj.Presentations.Open($out,0,0,0)
  }
 }
 if($Action -eq 'export' -and !$PreviewDir -and !$Pdf){throw 'export requires PreviewDir or Pdf'}
 $files=Previews;$info=DeckInfo
 if($KeepOpen -and $script:owned){[void]$script:deck.NewWindow()}
 $script:success=$true
 @{ok=$true;app=$script:session.progid;server=$script:session.server;output=$out;exports=$files;document=$info}|ConvertTo-Json -Depth 70
}catch{@{ok=$false;action=$Action;error=$_.Exception.Message;line=$_.InvocationInfo.ScriptLineNumber;detail=$_.ScriptStackTrace;output=$Output}|ConvertTo-Json -Depth 10;exit 1}
finally{
 $leave=$KeepOpen -and $script:success
 if($script:deck -and $script:owned -and !$leave){try{$script:deck.Saved=-1;$script:deck.Close()}catch{}}
 if($script:deck){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:deck)}catch{};$script:deck=$null}
 if($script:session){if($script:session.created -and !$leave){try{$script:session.obj.Quit()}catch{}};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:session.obj)}catch{}}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
