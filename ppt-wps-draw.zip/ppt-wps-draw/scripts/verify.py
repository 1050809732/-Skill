"""Exercise real Office roundtrips in a fresh subfolder, including source preservation."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
import xml.etree.ElementTree as ET


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--app', choices=['wps', 'powerpoint'], default='wps')
    p.add_argument('--work-dir')
    args = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    work = Path(tempfile.mkdtemp(prefix='office-roundtrip-', dir=args.work_dir))
    bridge = root / 'scripts/office.py'
    checks = []

    def run(action, *options, fail=False):
        r = subprocess.run([sys.executable, str(bridge), action, '--app', args.app, *map(str, options)],
                           capture_output=True, encoding='utf-8', timeout=150)
        try:
            result = json.loads(r.stdout)
        except Exception:
            raise AssertionError((r.returncode, r.stdout, r.stderr))
        assert bool(result['ok']) != fail, result
        assert (r.returncode != 0) == fail, result
        return result

    def dump(name, data):
        path = work / name
        path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        return path

    def objects(doc):
        def walk(items):
            for item in items:
                yield item
                yield from walk(item.get('children', []))
        return {item['path']: item for s in doc['slides'] for item in walk(s['objects'])}

    def digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    scene = json.loads((root / 'assets/demo-scene.json').read_text(encoding='utf-8'))
    # A tiny embedded PNG tests the bitmap branch; it is not an illustrative asset.
    image = work / 'pixel.png'
    image.write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='))
    scene['slides'].append({'name': 'compatibility', 'elements': [
        {'kind': 'shape', 'name': 'a', 'shape': 'rect', 'x': 50, 'y': 50, 'w': 100, 'h': 80, 'fill': '#AABBCC'},
        {'kind': 'shape', 'name': 'b', 'shape': 'ellipse', 'x': 300, 'y': 50, 'w': 100, 'h': 80, 'fill': '#DDEEFF'},
        {'kind': 'line', 'name': 'bound', 'x': 150, 'y': 90, 'x2': 300, 'y2': 90, 'begin': {'name': 'a', 'site': 4}, 'end': {'name': 'b', 'site': 2}, 'arrowEnd': 3},
        {'kind': 'freeform', 'name': 'polygon', 'points': [[50, 200], [150, 170], [170, 270]], 'closed': True, 'fill': '#88BB99', 'line': '#114422'},
        {'kind': 'image', 'name': 'bitmap-test', 'x': 300, 'y': 200, 'w': 10, 'h': 10, 'path': str(image)},
    ]})
    first = work / 'source.pptx'
    rendered = run('render', '--scene', dump('scene.json', scene), '--output', first,
                   '--preview-dir', work / 'preview', '--pdf', work / 'export.pdf')
    obj = objects(rendered['document'])
    assert len(rendered['document']['slides']) == 2
    assert obj['gateway/radio-wave']['type'] == 5
    assert obj['sensor-1/sensor-1-label']['text'] == 'S1'
    assert obj['bitmap-test']['type'] == 13
    assert len(rendered['exports']) == 3
    assert all(Path(f).stat().st_size > 0 for f in rendered['exports'])
    with zipfile.ZipFile(first) as z:
        raw = ET.fromstring(z.read('ppt/slides/slide1.xml'))
        ns0 = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main', 'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
        assert len(raw.findall('.//a:gradFill', ns0)) >= 5
        for node in raw.findall('.//p:sp', ns0):
            nv = node.find('p:nvSpPr/p:cNvPr', ns0)
            if nv is not None and nv.get('name') == 'radio-wave':
                pts = node.findall('.//a:cubicBezTo/a:pt', ns0)
                assert len(pts) == 3 and pts[0].get('x') == pts[1].get('x')
                assert pts[2].get('x') != pts[1].get('x')
    checks.append('native_shapes_curves_groups_connectors_image_png_pdf')
    original_hash = digest(first)

    changes = {'operations': [
        {'op': 'update', 'name': 'sensor-1/sensor-1-label', 'set': {'text': 'T1', 'textColor': '#123456'}},
        {'op': 'duplicate', 'name': 'output-dot', 'newName': 'copy-dot', 'set': {'x': 800, 'fill': '#FFAA00'}},
        {'op': 'add', 'element': {'kind': 'text', 'name': 'new-label', 'x': 760, 'y': 470, 'w': 150, 'h': 30, 'text': '新增标注', 'fontSize': 16}},
        {'op': 'group', 'name': 'test-group', 'members': ['copy-dot', 'new-label']},
        {'op': 'ungroup', 'name': 'test-group'},
        {'op': 'delete', 'name': 'copy-dot'},
    ]}
    patched = work / 'patched.pptx'
    run('patch', '--input-file', first, '--patch', dump('patch.json', changes), '--output', patched)
    reopened = objects(run('inspect', '--input-file', patched)['document'])
    assert reopened['sensor-1/sensor-1-label']['text'] == 'T1'
    assert reopened['new-label']['text'] == '新增标注'
    assert 'copy-dot' not in reopened
    assert digest(first) == original_hash
    checks.append('edit_duplicate_add_group_ungroup_delete_persist_source_unchanged')

    # Verify the saved format independently of COM inspection.
    ns = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
          'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
    with zipfile.ZipFile(patched) as z:
        xml = ET.fromstring(z.read('ppt/slides/slide1.xml'))
        all_text = [t.text for t in xml.findall('.//a:t', ns)]
        assert 'T1' in all_text and '新增标注' in all_text
        assert len(xml.findall('.//p:grpSp', ns)) >= 1
        assert len(xml.findall('.//p:pic', ns)) == 0
        assert len(xml.findall('.//p:sp', ns)) > 20
    checks.append('pptx_xml_native_objects_and_text')

    bad = dump('bad.json', {'operations': [
        {'op': 'update', 'name': 'title', 'set': {'text': 'temporary'}},
        {'op': 'update', 'name': 'missing-object', 'set': {'text': 'failure'}}]})
    failed_output = work / 'should-not-exist.pptx'
    run('patch', '--input-file', first, '--patch', bad, '--output', failed_output, fail=True)
    assert not failed_output.exists() and digest(first) == original_hash
    run('patch', '--input-file', first, '--patch', bad, '--output', first, fail=True)
    run('render', '--scene', work / 'scene.json', '--output', first, fail=True)
    assert digest(first) == original_hash
    checks.append('failed_edits_same_path_and_overwrite_protection')

    appended = work / 'appended.pptx'
    result = run('render', '--input-file', first, '--scene', root / 'assets/demo-scene.json', '--output', appended)
    assert len(result['document']['slides']) == 3 and digest(first) == original_hash
    checks.append('template_copy_append_preserves_original')
    report = {'ok': True, 'app': args.app, 'server': rendered.get('server'), 'checks': checks, 'work_dir': str(work)}
    (work / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    sys.stdout.reconfigure(encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
