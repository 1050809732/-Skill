"""Launch the local COM bridge in Windows PowerShell STA, without changing policy."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['probe', 'render', 'inspect', 'patch', 'export'])
    parser.add_argument('--app', choices=['auto', 'powerpoint', 'wps'], default='auto')
    for flag in ['scene', 'input-file', 'output', 'patch', 'preview-dir', 'pdf']:
        parser.add_argument('--' + flag)
    for flag in ['connect', 'active', 'keep-open', 'overwrite']:
        parser.add_argument('--' + flag, action='store_true')
    args = vars(parser.parse_args())
    if sys.platform != 'win32':
        parser.error('This bridge requires Windows and desktop PowerPoint or WPS.')
    names = {'action': 'Action', 'app': 'App', 'scene': 'Scene', 'input_file': 'InputFile',
             'output': 'Output', 'patch': 'Patch', 'preview_dir': 'PreviewDir', 'pdf': 'Pdf',
             'connect': 'Connect', 'active': 'Active', 'keep_open': 'KeepOpen', 'overwrite': 'Overwrite'}
    params = {names[k]: v for k, v in args.items() if v is not None and v is not False}
    env = dict(os.environ)
    env['PPT_WPS_SCRIPT'] = str(Path(__file__).with_suffix('.ps1').resolve())
    env['PPT_WPS_PYTHON'] = sys.executable
    env['PPT_WPS_PARAMS'] = json.dumps(params, ensure_ascii=False)
    command = ("$p=@{};($env:PPT_WPS_PARAMS|ConvertFrom-Json).PSObject.Properties|"
               "ForEach-Object{$p[$_.Name]=$_.Value};"
               "& ([scriptblock]::Create([IO.File]::ReadAllText($env:PPT_WPS_SCRIPT))) @p")
    exe = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    result = subprocess.run([str(exe), '-NoProfile', '-NonInteractive', '-STA', '-Command', command],
                            env=env, capture_output=True, encoding='utf-8', errors='replace')
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    if result.stdout:
        sys.stdout.write(result.stdout)
    if result.stderr:
        sys.stderr.write(result.stderr)
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
