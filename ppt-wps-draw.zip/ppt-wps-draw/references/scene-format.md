# 场景与编辑协议

运行 `python <skill>/scripts/office.py <action> ...`。启动器只用 Python 标准库，通过 Windows PowerShell 5.1 的 STA 命令执行本地脚本，不修改执行策略或宏设置。Python 路径由当前环境提供，不硬编码其他机器路径。

## 命令

```text
probe   [--app auto|powerpoint|wps] [--connect]
render  --scene scene.json --output new.pptx [--input-file template.pptx]
inspect --input-file figure.pptx
inspect --app powerpoint --active
patch   --input-file figure.pptx --patch patch.json --output new.pptx
export  --input-file figure.pptx --preview-dir previews [--pdf figure.pdf]
```

render/patch 可加 `--preview-dir`、`--pdf`、`--keep-open`；所有操作可显式 `--overwrite` 覆盖输出。--active 只读当前文档。没有 --keep-open 时关闭脚本自己打开的副本；只退出脚本自己启动且无需保留的应用，不关闭已有用户窗口。失败时关闭脚本副本，源文件不保存。

probe 的 server 是实际 COM 程序路径。某些 WPS 安装会接管 PowerPoint.Application，因此该接口连接成功不等于电脑安装了微软 PowerPoint。报告实际后端。WPS 不完整实现渐变和贝塞尔 COM 参数，脚本在保存后通过 native_xml.py 修复原生 DrawingML，再重新打开并导出预览，不会栅格化这些对象。

## 场景

```json
{
  "width": 1200, "height": 675,
  "pageWidth": 960, "pageHeight": 540,
  "slides": [{
    "name": "diagram", "background": "#FFFFFF",
    "elements": [
      {"kind":"shape", "name":"node", "shape":"ellipse", "x":100,"y":150,"w":90,"h":90,"fill":"#D7F0EA","line":"#247F70","lineWidth":2},
      {"kind":"text", "name":"label", "x":80,"y":250,"w":140,"h":36,"text":"传感节点","font":"Microsoft YaHei","fontSize":24,"textColor":"#172B3A","align":"center"},
      {"kind":"line", "name":"flow", "x":220,"y":195,"x2":450,"y2":195,"line":"#247F70","lineWidth":3,"arrowEnd":3}
    ]
  }]
}
```

width/height 是场景坐标单位，pageWidth/pageHeight 为 PowerPoint 点数，省略时与画布相同。x/y/w/h 使用场景单位，线宽与字号乘 min(pageWidth/width,pageHeight/height)。模板场景自动采用模板实际页面尺寸，不改变模板现有对象。避免非等比画布造成形变。

元素按顺序加入，后加入位于上方。name 每页唯一且不得包含 `/`。所有类型可设置 fill、line、lineWidth、transparency (0..1)、rotation、z(front/back)。line/fill 的 none 或 null 表示隐藏。fill 可以是十六进制色，或 `{ "from":"#E3F1F5", "to":"#367CA1", "style":1, "variant":1 }`。WPS 修复支持 style 1 水平、2 垂直、3/4 两种对角方向，以及 variant 2/4 反转方向。暂不支持中心辐射渐变。

- **shape**：x/y/w/h 和 shape。支持 rect、roundRect、ellipse、triangle、diamond、hexagon、chevron、parallelogram、cloud、rightArrow、leftArrow、upArrow、downArrow、cylinder。
- **text**：x/y/w/h 和 text。font、fontSize、textColor、bold、align(left/center/right)、valign(top/middle/bottom)、margin。shape 也可包含 text。默认不自动缩小字体，预览检查换行和溢出。
- **line**：x/y 为起点，x2/y2 为终点；connector 为 1 直线、2 肘形、3 曲线；arrowEnd/arrowStart 使用 Office MsoArrowheadStyle（1 无，3 三角）；dash 用 Office MsoLineDashStyle。可加 begin/end 为 `{ "name":"node", "site":1 }` 绑定既有形状。绑定对象应先创建；站点编号由目标形状决定。
- **freeform**：points 首项 `[x,y]`，后续每项为直线终点 `[x,y]` 或三次贝塞尔段 `[c1x,c1y,c2x,c2y,x,y]`。closed 为 true 时连回起点。默认无填充，可显式 fill。所有节点保持原生可编辑。
- **image**：x/y/w/h 和 path。render 相对路径以 scene 文件目录为基准，patch 图片要求绝对路径。图片按给定尺寸放置，调用者保持原始纵横比，嵌入而不外链。
- **group**：members 为同页顶层对象名数组，至少两个，不重复。组必须排在成员之后。不要在组上设置 text。inspect 使用 `group/child` 展示子对象，组内对象能单独 update。

## 增量修改

patch 坐标和字号使用页面点数，不使用原 scene 单位。输入输出必须不同。所有操作在内存副本完成后才保存；操作失败不写入输出 PPTX，预览失败则 JSON 报错并保留已保存的 PPTX。

```json
{"operations":[
 {"op":"update","slide":1,"name":"node","set":{"x":120,"fill":"#F2B84B"}},
 {"op":"update","slide":1,"name":"label","set":{"text":"温度传感器","fontSize":22}},
 {"op":"duplicate","slide":1,"name":"node","newName":"node-copy","set":{"x":300}},
 {"op":"add","slide":1,"element":{"kind":"text","name":"note","x":40,"y":400,"w":500,"h":30,"text":"补充说明","fontSize":20}},
 {"op":"group","slide":1,"name":"cluster","members":["node","label"]},
 {"op":"update","slide":1,"name":"cluster/label","set":{"textColor":"#186D60"}},
 {"op":"ungroup","slide":1,"name":"cluster"},
 {"op":"delete","slide":1,"name":"node-copy"}
]}
```

inspect 的 type 是 Office MsoShapeType：1 自选图形，5 自由形状，6 组，13 图片，17 文本框，其他值直接按实际类型返回。图片数量需要递归统计 children。不要将类型 6 组误当单个不可编辑图片。

duplicate 适用于顶层对象或完整组；要复制组内子对象，先解组。WPS 的 Duplicate 方法未生成对象时，脚本会使用原生 Copy/Paste 回退，此操作会写系统剪贴板。新建精确路径后如需再移动缩放，先保存再在下一条 patch 中修改，避免同批创建与几何修改发生歧义。已有自由路径可以直接修改位置和大小。

`python <skill>/scripts/verify.py --app wps --work-dir <existing-directory>` 会在新建临时子目录内做实际应用往返测试。检查保存格式中的原生对象、曲线控制点、渐变、修改持久化及失败时源文件保持不变；测试不依赖截图像素相等。
